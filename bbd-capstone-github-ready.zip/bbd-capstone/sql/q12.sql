-- Find the largest completed order amounts.
SELECT order_id, amount
FROM orders
WHERE status='completed'
ORDER BY amount DESC, order_id
LIMIT 10;
