-- List orders that are still pending.
SELECT order_id, order_date, status, amount
FROM orders
WHERE status = 'pending'
ORDER BY order_id;
