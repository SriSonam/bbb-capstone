-- Find best-selling products by completed units.
SELECT p.product_name, SUM(oi.quantity) AS units_sold,
       SUM(oi.quantity * oi.unit_price) AS item_sales
FROM orders o
JOIN order_items oi ON oi.order_id = o.order_id
JOIN products p ON p.product_id = oi.product_id
WHERE o.status = 'completed'
GROUP BY p.product_name
ORDER BY units_sold DESC, item_sales DESC;
