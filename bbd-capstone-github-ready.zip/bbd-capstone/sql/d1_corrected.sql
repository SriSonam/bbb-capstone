-- Corrected Part D query: compare monthly completed revenue with the previous month.
-- The result contains two rows with comparable month-over-month growth values.
WITH monthly AS (
  SELECT order_month, SUM(amount) AS revenue
  FROM orders
  WHERE status = 'completed'
  GROUP BY order_month
),
lagged AS (
  SELECT order_month, revenue,
         LAG(revenue) OVER (ORDER BY order_month) AS previous_revenue
  FROM monthly
)
SELECT order_month, revenue, previous_revenue,
       ROUND(100.0 * (revenue - previous_revenue) / NULLIF(previous_revenue, 0), 1) AS growth_pct
FROM lagged
WHERE previous_revenue IS NOT NULL
ORDER BY order_month
LIMIT 2;
