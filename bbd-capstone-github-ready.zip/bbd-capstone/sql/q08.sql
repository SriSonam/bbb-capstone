-- Check each sales representative against a 80,000 target.
SELECT sales_rep, SUM(amount) AS revenue,
       80000 AS target,
       CASE WHEN SUM(amount) >= 80000 THEN 'Met target' ELSE 'Below target' END AS target_status
FROM orders
WHERE status = 'completed'
GROUP BY sales_rep
ORDER BY sales_rep;
