-- Export the order-level enriched table for Part B.
SELECT o.order_id, o.order_date, o.order_month, o.status,
       c.customer_name, c.city, c.region, o.sales_rep,
       COALESCE((SELECT SUM(oi.quantity) FROM order_items oi WHERE oi.order_id=o.order_id), 0) AS quantity,
       o.amount
FROM orders o
JOIN customers c ON c.customer_id=o.customer_id
ORDER BY o.order_id;
