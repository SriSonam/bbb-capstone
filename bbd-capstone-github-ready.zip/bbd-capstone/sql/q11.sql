-- Show completed revenue and units by region for AI verification.
SELECT c.region, SUM(o.amount) AS revenue,
       SUM(oi.quantity) AS units
FROM orders o
JOIN customers c ON c.customer_id=o.customer_id
JOIN order_items oi ON oi.order_id=o.order_id
WHERE o.status='completed'
GROUP BY c.region
ORDER BY c.region;
