-- Show completed revenue by region.
SELECT c.region, SUM(o.amount) AS revenue
FROM orders o JOIN customers c ON c.customer_id = o.customer_id
WHERE o.status = 'completed'
GROUP BY c.region
ORDER BY revenue DESC;
