# SQL Query Results

## Seed check: 49, 24, 90, 137

| Table | Rows |
|---|---:|
| customers | 49 |
| products | 24 |
| orders | 90 |
| order_items | 137 |

## q01

**Question:** List orders that are still pending.

**Rows returned:** 20

Showing first 5 rows of the result.

| order_id | order_date | status | amount |
|---|---|---|---|
| 1001 | 2025-01-01 | pending |  |
| 1010 | 2025-04-10 | pending |  |
| 1063 | 2025-03-09 | pending | 700.0 |
| 1064 | 2025-04-10 | pending |  |
| 1066 | 2025-06-12 | pending | 8400.0 |

## q02

**Question:** Find orders with missing amounts and check their status.

**Rows returned:** 3

| order_id | status | amount |
|---|---|---|
| 1001 | pending |  |
| 1010 | pending |  |
| 1064 | pending |  |

## q03

**Question:** Calculate revenue from completed orders only.

**Rows returned:** 1

| completed_orders | total_revenue |
|---|---|
| 63 | 346200.0 |

## q04

**Question:** Show completed revenue by region.

**Rows returned:** 4

| region | revenue |
|---|---|
| West | 118200.0 |
| North | 93600.0 |
| East | 91500.0 |
| South | 42900.0 |

## q05

**Question:** Find best-selling products by completed units.

**Rows returned:** 3

| product_name | units_sold | item_sales |
|---|---|---|
| Wireless Earbuds | 92 | 276000.0 |
| Air Fryer | 12 | 62400.0 |
| Smart Watch | 2 | 7800.0 |

## q06

**Question:** Summarise completed revenue by product category.

**Rows returned:** 2

| category | revenue |
|---|---|
| Electronics | 283800.0 |
| Kitchen | 62400.0 |

## q07

**Question:** Compare completed revenue by month.

**Rows returned:** 6

| order_month | revenue |
|---|---|
| 2025-01 | 60600.0 |
| 2025-02 | 51900.0 |
| 2025-03 | 64500.0 |
| 2025-04 | 42000.0 |
| 2025-05 | 79200.0 |
| 2025-06 | 48000.0 |

## q08

**Question:** Check each sales representative against a 80,000 target.

**Rows returned:** 4

| sales_rep | revenue | target | target_status |
|---|---|---|---|
| Asha | 93600.0 | 80000 | Met target |
| Bharat | 42900.0 | 80000 | Below target |
| Charan | 91500.0 | 80000 | Met target |
| Divya | 118200.0 | 80000 | Met target |

## q09

**Question:** Export the order-level enriched table for Part B.

**Rows returned:** 90

Showing first 5 rows of the result.

| order_id | order_date | order_month | status | customer_name | city | region | sales_rep | quantity | amount |
|---|---|---|---|---|---|---|---|---|---|
| 1001 | 2025-01-01 | 2025-01 | pending | Customer 01 | Delhi | North | Asha | 3 |  |
| 1002 | 2025-02-02 | 2025-02 | completed | Customer 08 | Pune | West | Divya | 2 | 6000.0 |
| 1003 | 2025-03-03 | 2025-03 | completed | Customer 15 | Patna | East | Charan | 2 | 6000.0 |
| 1004 | 2025-04-04 | 2025-04 | completed | Customer 22 | Chennai | South | Bharat | 2 | 6000.0 |
| 1005 | 2025-05-05 | 2025-05 | completed | Customer 29 | Jaipur | North | Asha | 2 | 6000.0 |

## q10

**Question:** Count orders by status.

**Rows returned:** 3

| status | order_count |
|---|---|
| completed | 63 |
| disputed | 7 |
| pending | 20 |

## q11

**Question:** Show completed revenue and units by region for AI verification.

**Rows returned:** 4

| region | revenue | units |
|---|---|---|
| East | 91500.0 | 28 |
| North | 93600.0 | 29 |
| South | 42900.0 | 14 |
| West | 118200.0 | 35 |

## q12

**Question:** Find the largest completed order amounts.

**Rows returned:** 10

| order_id | amount |
|---|---|
| 1061 | 15600.0 |
| 1065 | 15600.0 |
| 1069 | 15600.0 |
| 1077 | 15600.0 |
| 1002 | 6000.0 |
| 1003 | 6000.0 |
| 1004 | 6000.0 |
| 1005 | 6000.0 |
| 1006 | 6000.0 |
| 1007 | 6000.0 |

## q13

**Question:** Find sales representatives with revenue below the team average.

**Rows returned:** 1

| sales_rep | revenue |
|---|---|
| Bharat | 42900.0 |
