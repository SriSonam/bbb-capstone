# Big Billion Days Regional Performance Review

## Project overview
A four-part retail analytics capstone: SQL reporting, spreadsheet cleaning, dashboard planning, and AI-assisted verification.

> **Important dataset note:** This repository contains a synthetic validation dataset created to reproduce the brief's structural and headline checks (49 customers, 24 products, 90 orders, 137 order items; 63 completed orders; revenue 346,200; 106 units). It is not the official assignment dataset. Replace the four source CSVs with the official data before final assessment if supplied.

## SQL compiler and dialect
- Database: SQLite
- Run `sql/00_schema_and_seed.sql` first. It creates and seeds all four tables.
- Run each query in `sql/q01.sql` through `sql/q13.sql`.
- Run the Part D correction with `sql/d1_corrected.sql`.

## Spreadsheet tool
Google Sheets (Excel can also be used). Keep `order_month` as text and preserve missing amounts as blanks.

## Tableau
Dashboard design specification only: **Tableau build included? No.** See `docs/dashboard_spec.md` for the implementation plan.

## Three key findings
1. The validation dataset contains 90 orders, including 63 completed orders.
2. Completed-only revenue is 346,200 across 106 units.
3. The four 15,600 completed orders (IDs 1061, 1065, 1069, 1077) each represent 3 Air Fryers at 5,200 per unit.

## Revenue rule
Revenue = sum of `amount` only where `status = 'completed'`. Pending and disputed orders are excluded. Missing amounts remain blank, not zero.

## File index
- `sql/00_schema_and_seed.sql`: SQLite schema and synthetic seed data
- `sql/q01.sql` … `sql/q13.sql`: thirteen reporting queries
- `sql/d1_corrected.sql`: Part D corrected month-over-month query
- `results/query_results.md`: row counts and query outputs
- `data/customers.csv`, `data/products.csv`, `data/orders.csv`, `data/order_items.csv`: source validation tables
- `data/orders_enriched.csv`: Part A export (90 rows × 10 columns)
- `data/orders_clean.csv`: Part B export (63 rows × 13 columns)
- `docs/spreadsheet_notes.md`: formulas, aggregates, pivots and validation
- `docs/dashboard_spec.md`: dimensions, measures, KPIs, charts and recommendations
- `docs/ai_log.md`: prompt, defects and verification protocol

## Assumptions
- SQLite is the SQL dialect.
- The sales target used in q08 is 80,000 per representative because the brief does not specify the target amount.
- The dataset is synthetic and for validation/demo use; findings beyond the required acceptance checks are illustrative.
