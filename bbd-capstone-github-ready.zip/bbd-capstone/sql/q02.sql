-- Find orders with missing amounts and check their status.
SELECT order_id, status, amount
FROM orders
WHERE amount IS NULL
ORDER BY order_id;
