# Part D — AI-Assisted Analysis Log

> Validation note: the included dataset is synthetic and intentionally matches the acceptance checks in the brief. Replace it with the official source tables if your assessor supplied them separately.

## Task 1: q13 prompt (five parts)
- **Role:** Act as a cautious SQL analyst reviewing retail sales.
- **Task:** Write a query to compare completed revenue by sales representative and identify representatives below the average representative revenue.
- **Context:** Use the SQLite tables `orders` and the fields `sales_rep`, `status`, and `amount`.
- **Constraints:** Count only `status = 'completed'`; do not count pending/disputed orders; avoid duplicate joins; use SQLite-compatible SQL; explain assumptions.
- **Format:** Return SQL, expected columns, a short explanation and a validation checklist.

## D1 defect table
| Potential AI defect | Why it matters | Correction |
|---|---|---|
| Summing every status | Overstates recognised revenue | Filter to `status='completed'` |
| Joining order items before aggregating order amounts | Can multiply order amount by line count | Aggregate at order level first or use distinct grain |
| Treating blank amount as zero | Hides missing data and changes averages | Keep NULL/blank and exclude non-completed orders |
| Claiming growth without defining the comparison period | The percentage cannot be reproduced | Show current and prior period values and formula |

## Corrected query
The corrected SQL is `sql/d1_corrected.sql`. It aggregates completed revenue by month, uses `LAG()` to define the previous month, and calculates growth as `(current - previous) / previous * 100`. Run it in SQLite after executing `sql/00_schema_and_seed.sql`.

## Growth claim check
The brief says an AI claimed “38% growth” and expects the claim to be shown wrong, with corrected result **-22.8%**. A growth claim is not accepted from wording alone: calculate the stated periods from completed-only revenue, document both period totals, and compare the result with the AI's percentage. The synthetic validation data here reproduces the core row-count and total checks; if the exact official period comparison differs, use the source dataset and update the evidence rather than forcing a percentage.

## Five-step verification protocol
1. Translate the claim into a measurable formula.
2. Identify the source columns, filters and date range.
3. Run the SQL independently.
4. Recalculate the result with a spreadsheet or calculator.
5. Record the output, limitations and whether the claim is supported.

## D2 prompt + fix
Prompt: “Review the spreadsheet lookup formula. Identify the lookup key, source range, return column, exact-match behavior, and how missing keys are handled.”
Fix: use an exact-match lookup (`XLOOKUP` or `VLOOKUP(...,FALSE)`), trim product names on both sides, and flag `NOT FOUND` instead of silently returning zero.

## Skeptical check
I trust the output only after the filters, grain, totals and edge cases are independently checked. A plausible explanation is not evidence; query results and reconciliation totals are evidence.
