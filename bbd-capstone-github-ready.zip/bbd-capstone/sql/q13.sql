-- Find sales representatives with revenue below the team average.
WITH rep_sales AS (
  SELECT sales_rep, SUM(amount) AS revenue
  FROM orders
  WHERE status='completed'
  GROUP BY sales_rep
)
SELECT sales_rep, revenue
FROM rep_sales
WHERE revenue < (SELECT AVG(revenue) FROM rep_sales)
ORDER BY revenue;
