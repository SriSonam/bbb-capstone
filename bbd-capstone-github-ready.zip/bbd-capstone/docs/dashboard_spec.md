# Part C — Dashboard Specification

## Data source (13 fields)
`order_id` (Dimension), `order_date` (Dimension), `order_month` (Dimension), `status` (Dimension), `customer_name` (Dimension), `city` (Dimension), `region` (Dimension), `sales_rep` (Dimension), `product_name` (Dimension), `category` (Dimension), `quantity` (Measure), `unit_price` (Measure), `amount` (Measure). Filter to `status = completed` for all revenue KPIs and charts.

## KPI cards
- **Completed revenue:** 346,200
- **Units sold:** 106

## Four charts
1. **Revenue by region:** horizontal bar chart; region on axis, SUM(amount) as value.
2. **Revenue by category:** sorted bar chart; category on axis, SUM(amount) as value.
3. **Monthly revenue trend:** line chart; order_month on x-axis, SUM(amount) on y-axis, sorted chronologically.
4. **Order detail:** table showing order ID, date, region, rep, product, quantity and amount; sort amount descending.

## Dashboard layout
Place the title and date/status filter at the top. Put the two KPI cards directly below. Put region and category charts in the middle row, monthly trend across the lower-left, and order detail table on the lower-right or below the charts. Keep the completed-only filter visible and label revenue as “Completed revenue”.

## Narrative — summary
The dataset contains 90 orders, of which 63 are completed. Completed revenue is 346,200 across 106 units. Pending and disputed orders are not counted as revenue.

## Narrative — analysis
Compare regions and categories using the completed-only filter. Use the monthly line chart to identify peaks and dips; use the detail table to validate unusual values before making decisions. The four 15,600 orders are traceable to 3 Air Fryers × 5,200 each.

## Three recommendations
1. Allocate the next promotional test to the region with the highest completed revenue in the region chart, then compare conversion and revenue after the campaign.
2. Test category-specific offers for the highest-revenue category, using a control group rather than assuming correlation proves promotion impact.
3. Review pending orders with operations before spending more on acquisition; monitor completion rate and recovered revenue separately.

## Reconciliation
The completed revenue total must read 346,200 in the KPI card, region chart grand total, category chart grand total and monthly trend grand total. Units KPI must read 106. If any figure differs, inspect status filtering, duplicated joins and blank amounts.
