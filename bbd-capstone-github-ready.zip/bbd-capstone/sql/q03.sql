-- Calculate revenue from completed orders only.
SELECT COUNT(*) AS completed_orders,
       SUM(amount) AS total_revenue
FROM orders
WHERE status = 'completed';
