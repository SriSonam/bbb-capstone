-- Compare completed revenue by month.
SELECT order_month, SUM(amount) AS revenue
FROM orders
WHERE status = 'completed'
GROUP BY order_month
ORDER BY order_month;
