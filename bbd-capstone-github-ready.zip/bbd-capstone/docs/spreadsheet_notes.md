# Part B — Spreadsheet Cleaning and Pivots

## (a) Formulas, as text
- Trim names: `=TRIM(E2)` (fill down; paste values when finished).
- Standardise status: `=LOWER(TRIM(D2))`.
- Category lookup: `=XLOOKUP(I2,products!B:B,products!C:C,"NOT FOUND")` (or `VLOOKUP` if XLOOKUP is unavailable).
- Unit price lookup: `=XLOOKUP(I2,products!B:B,products!D:D,"NOT FOUND")`.
- Completed revenue: `=IF(D2="completed",M2,0)`.

## (b) Five aggregates
1. Completed orders: `=COUNTIF(D2:D91,"completed")` → 63.
2. Completed revenue: `=SUMIF(D2:D91,"completed",J2:J91)` → 346,200.
3. Completed units: `=SUMIF(D2:D91,"completed",I2:I91)` → 106.
4. Missing amounts: `=COUNTBLANK(J2:J91)` → 3 (orders 1001, 1010, 1064).
5. Unique order IDs: `=COUNTUNIQUE(A2:A91)` → 90.

## (c) Two pivots + totals
- Pivot 1: Rows = `region`; Values = SUM of `amount`; filter `status = completed`. Grand total = 346,200.
- Pivot 2: Rows = `region`; Columns = `category`; Values = SUM of `amount`; filter `status = completed`. Grand total = 346,200.
- Product/category lookup fields are included in `orders_clean.csv`; use the product table as the lookup source.

## (d) Reconciliation
The clean CSV contains 63 completed orders and 13 columns. Its revenue sum is 346,200 and its unit sum is 106, matching the assignment's acceptance checks. Revenue always excludes pending and disputed orders.

## (e) Data validation
- Missing amounts: orders 1001, 1010, and 1064 are pending. Leave amounts blank, not zero; these rows are excluded by the completed-only filter.
- Duplicates: `COUNTUNIQUE(A2:A91)=90`; no duplicate order IDs.
- Types: amount, quantity and unit_price should be numeric; order_month should remain text.
- Outlier: completed amount 15,600 appears for orders 1061, 1065, 1069, and 1077. Each is 3 Air Fryers × 5,200, so it is explainable rather than an error.
- Handover note: “Revenue counts completed orders only. Missing amounts remain blank, never zero. order_month stays plain text.”

## (f) Setup
Import `data/orders_enriched.csv` into Google Sheets. Keep `order_month` as plain text. Use the product lookup table for category and price, filter completed orders, and export the 63-row result as `data/orders_clean.csv`.
